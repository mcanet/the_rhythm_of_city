#!/usr/bin/python
from time import sleep
from threadPool import threadPool
from twitter import twitterRSS  
from flickr import flickr
from youtube import youtubeRSS
from generalStats import generalStats

class threadManager():
    def __init__(self, totalCities):
		self.myGeneralStats = generalStats()
		self.cities = self.myGeneralStats.getCurrentCities()
		self.totalCities = totalCities
		self.twitter = {}
		for i in range(0, self.totalCities ):
			self.twitter[i]= twitterRSS(self.cities[i]) 
		
		self.flickr = {}
		for i in range(0, self.totalCities ):
			self.flickr[i] = flickr(self.cities[i]) 
			
		self.youtube = {}	
		for i in range(0, self.totalCities ):
			self.youtube[i] = youtubeRSS(self.cities[i]) 

    def runTasks(self):
        print "runTasks"

        # twitter data pool
        self.pool = threadPool( self.totalCities )
        for i in range(0, self.totalCities ):
            self.addProcess(self.pool, self.twitter[i].getData)
        self.endFinishProcess(self.pool) 
		# flickr data pool
        self.pool2 = threadPool( self.totalCities )
        for i in range(0, self.totalCities ):
            self.addProcess(self.pool2, self.flickr[i].getData)
        self.endFinishProcess(self.pool2)
		# flickr data pool
        self.pool3 = threadPool( self.totalCities )
        for i in range(0, self.totalCities ):
            self.addProcess(self.pool3, self.youtube[i].getData)
        self.endFinishProcess(self.pool3)
      	
    def addProcess(self, pool, task, arg=""):
        pool.queueTask(task, arg)

    def endFinishProcess(self, pool, waitForTasks = True, waitForThreads = False):
        pool.joinAll(waitForTasks,waitForThreads)

if __name__ == "__main__":
	tm = threadManager()