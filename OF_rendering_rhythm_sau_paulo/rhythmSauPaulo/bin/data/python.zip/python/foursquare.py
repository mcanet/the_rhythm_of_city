
# documentation API: https://developer.foursquare.com/docs/venues/trending

url = "https://api.foursquare.com/v2/venues/trending?ll=40.7,-74&limit=50&radius=2000&oauth_token=PD1TXEZIYLL1BJ01W1XMAVOC4301UZPME155XPT31THGLCCI&v=20121207"